# Formulario Plano Moderno con Menú animado Efecto Sliding, One Window, Versión Completa/ C#, WinForm (Beta)+Pasar Datos Entre Formularios

<h2>Tutorial:</h2>
<h3>Blog:</h3>
https://rjcodeadvance.com/parte-2-formulario-plano-moderno-con-menu-animado-efecto-sliding-one-window-version-completa-c-winform-pasar-datos-entre-forms/
<h3>YouTube:</h3>
https://www.youtube.com/watch?v=vQrADCBPoGk

<div align='center'>
 <h1>Pink Dark Theme</h1>
</div>
<img src="https://rjcodeadvance.com/wp-content/uploads/2019/06/Formulario-modernista-MODERN-FLAT-GUI-2.png">
